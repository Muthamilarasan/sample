package com.stackroute.moviecruiser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;

//import com.stackroute.moviecruiser.config.JwtFilter;

@SpringBootApplication
public class MovieCruiserAuthenticationServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieCruiserAuthenticationServiceApplication.class, args);

	}
	
}
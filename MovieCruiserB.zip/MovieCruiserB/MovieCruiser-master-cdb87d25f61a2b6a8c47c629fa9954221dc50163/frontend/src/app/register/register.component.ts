import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { AlertService } from './../services/alert.service';
import { RegisterService } from './../services/register.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
  encapsulation: ViewEncapsulation.None,
  providers: [RegisterService]
})
export class RegisterComponent implements OnInit {
  public model: any = {};

  constructor(
    private service: RegisterService,
    private router: Router,
    private alertService: AlertService
  ) {}

  public ngOnInit() {}

  public register() {
    this.service.registerUser(this.model).subscribe(
      response => {
        if (response.success) {
          this.alertService.success('Registration successful', true);
          this.router.navigate(['/login']);
        }
      },
      error => {
        if (error.status === 409) {
          this.alertService.error('Registration failed, user already exists');
        }
      }
    );
  }
}

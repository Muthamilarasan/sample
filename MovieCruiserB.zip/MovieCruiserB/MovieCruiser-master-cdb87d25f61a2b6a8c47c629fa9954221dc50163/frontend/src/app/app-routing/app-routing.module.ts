import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { DiscoverMoviesComponent } from "./../discover-movies/discover-movies.component";
import { DiscoverTvComponent } from "./../discover-tv/discover-tv.component";
import { AuthGuard } from "./../guards/index";
import { HomeComponent } from "./../home/home.component";
import { LoginComponent } from "./../login/login.component";
import { LogoutComponent } from "./../logout/logout.component";
import { MovieComponent } from "./../movie/movie.component";
import { RegisterComponent } from "./../register/register.component";
import { SearchResultsComponent } from "./../search-results/search-results.component";
import { SearchComponent } from "./../search/search.component";
import { TvShowComponent } from "./../tv-show/tv-show.component";
import { WatchlistComponent } from "./../watchlist/watchlist.component";

const routes: Routes = [
	{
		path: "",
		// tslint:disable-next-line:object-literal-sort-keys
		component:
			localStorage.getItem("token") === null ? LoginComponent : HomeComponent,
		canActivate: [AuthGuard]
	},
	{
		path: "search-results",
		component: SearchResultsComponent,
		canActivate: [AuthGuard]
	},
	{ path: "search", component: SearchComponent, canActivate: [AuthGuard] },
	{ path: "movie/:id", component: MovieComponent, canActivate: [AuthGuard] },
	{ path: "tv/:id", component: TvShowComponent, canActivate: [AuthGuard] },
	{
		path: "watchlist",
		component: WatchlistComponent,
		canActivate: [AuthGuard]
	},
	{ path: "home", component: HomeComponent, canActivate: [AuthGuard] },
	{
		path: "discover-movies",
		component: DiscoverMoviesComponent,
		canActivate: [AuthGuard]
	},
	{
		path: "discover-tv",
		component: DiscoverTvComponent,
		canActivate: [AuthGuard]
	},
	{ path: "login", component: LoginComponent },
	{ path: "register", component: RegisterComponent },
	{ path: "logout", component: LogoutComponent }
];
@NgModule({
	imports: [RouterModule.forRoot(routes)],
	exports: [RouterModule]
})
export class AppRoutingModule {}

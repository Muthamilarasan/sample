import { Injectable } from "@angular/core";
import { Headers, Http } from "@angular/http";

@Injectable()
export class LoginService {
	private headers = new Headers({
		"Content-Type": "application/json",
		Accept: "application/json"
	});
	private serviceUrl = "http://localhost:8089/user/";

	constructor(private http: Http) {}

	public login(model) {
		const url = this.serviceUrl + "login/";
		const json = JSON.stringify({
			userId: model.username,
			password: model.password
		});

		return this.http
			.post(this.serviceUrl + "login/", json, { headers: this.headers })
			.map(res => res.json(), err => err.json());
	}

	private handleError(error: any) {
		// console.error('An error occurred', error); // for demo purposes only
	}
}

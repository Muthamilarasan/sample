import { Injectable } from "@angular/core";
import { Headers, Http } from "@angular/http";
import "rxjs/Rx";
import { Movie } from "../movie";
@Injectable()
export class MoviesService {
	private headers = new Headers({
		"Content-Type": "application/json",
		Accept: "application/json",
		Authorization: "Bearer " + localStorage.getItem("token")
	});
	private serviceUrl = "http://localhost:8080/api/movie/";

	constructor(private http: Http) {}

	public addToWatchListMovie(
		id: number,
		name: string,
		comments: string,
		posterPath: string,
		releaseDate: Date,
		voteAverage: number,
		voteCount: number
	) {
		// const url = this.serviceUrl + 'save/';
		const json = JSON.stringify({
			id,
			name,
			comments,
			posterPath,
			releaseDate,
			voteAverage,
			voteCount,
			userId: localStorage.getItem("userId")
		});
		return this.http
			.post(this.serviceUrl, json, { headers: this.headers })
			.toPromise()
			.catch(this.handleError);
	}

	public getWatchList() {
		return this.http
			.get(this.serviceUrl + "myMovies", { headers: this.headers })
			.toPromise()
			.then(res => res.json(), err => err.json());
	}

	public checkWatchList(id: number) {
		const url = this.serviceUrl + "get/" + id;
		return this.http
			.get(url)
			.toPromise()
			.then(res => (res ? res.json() : null))
			.catch(this.handleError);
	}

	public updateMovieComments(id: number, comments: string) {
		const url = this.serviceUrl + "update/" + id;
		return this.http
			.put(url, comments, { headers: this.headers })
			.toPromise()
			.catch(this.handleError);
	}

	public removeMovieFromWatchList(id: number) {
		// const uri = `${this.serviceUrl}${id}`;
		const url = this.serviceUrl + "delete/" + id;
		return this.http
			.delete(url, { headers: this.headers })
			.toPromise()
			.catch(this.handleError);
	}

	private handleError(error: any) {
		// console.error('An error occurred', error); // for demo purposes only
	}
}

import { Injectable } from "@angular/core";
import { Headers, Http } from "@angular/http";

@Injectable()
export class RegisterService {
	private headers = new Headers({
		"Content-Type": "application/json",
		Accept: "application/json"
	});
	private serviceUrl = "http://localhost:8089/user/";

	constructor(private http: Http) {}

	public registerUser(model) {
		const url = this.serviceUrl + "register/";
		const json = JSON.stringify({
			firstName: model.firstName,
			lastName: model.lastName,
			userId: model.username,
			password: model.password
		});
		// return this.http.post(this.serviceUrl + 'register/', json, { headers: this.headers }).toPromise().catch(this.handleError);
		return this.http
			.post(this.serviceUrl + "register/", json, { headers: this.headers })
			.map(res => res.json(), err => err.json());
	}

	private handleError(error: any) {
		// console.error('An error occurred', error); // for demo purposes only
	}
}

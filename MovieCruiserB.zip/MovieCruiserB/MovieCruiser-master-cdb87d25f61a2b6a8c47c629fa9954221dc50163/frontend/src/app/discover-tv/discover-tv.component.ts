import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { SearchService } from "../services/search.service";

@Component({
	selector: "app-discover-tv",
	templateUrl: "./discover-tv.component.html",
	styleUrls: ["./discover-tv.component.css"]
})
export class DiscoverTvComponent implements OnInit {
	public discTV: object[] = [];
  
  constructor(private searchService: SearchService, private router: Router) {}
  
	public ngOnInit() {
		this.searchService.discoverTV().subscribe(response => {
			this.discTV = response.results;
		});
	}

	public goToDetailTV(id: number) {
		const link = ["/tv", id];
		this.router.navigate(link);
	}
}

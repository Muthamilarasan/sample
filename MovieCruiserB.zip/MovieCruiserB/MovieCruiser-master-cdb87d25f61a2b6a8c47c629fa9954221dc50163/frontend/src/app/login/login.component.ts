import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { AlertService } from './../services/alert.service';
import { LoginService } from './../services/login.service';
// import 'rxjs/add/operator/switchMap';
// import { ActivatedRoute, ParamMap, Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  encapsulation: ViewEncapsulation.None,
  providers: [LoginService]
})
export class LoginComponent implements OnInit {
  public model: any = {};
  // private route: ActivatedRoute;

  constructor(
    private service: LoginService,
    private router: Router,
    private alertService: AlertService
  ) {}

  public ngOnInit() {}

  public login() {
    this.service.login(this.model).subscribe(
      response => {
        if (response.token) {
          this.router.navigate(['/home']);
          localStorage.setItem('token', response.token);
          localStorage.setItem('userId', this.model.username);
          window.location.reload();
        }
      },
      error => {
        if (error.status === 401) {
          this.alertService.error('Username or password is incorrect.');
        }
      }
    );
  }
}

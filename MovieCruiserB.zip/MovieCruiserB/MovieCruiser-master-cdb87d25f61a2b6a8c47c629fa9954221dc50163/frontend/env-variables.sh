export MYSQL_DATABASE="movie_db"
export MYSQL_USER="root"
export MYSQL_PASSWORD="root"